//Виводить прізвище в термінал
console.log("Козлівський");

// Оголошення змінних
let number = 543;
let string = "StringValue";

// Виведення змінних на екран
alert(number);
alert(string);

// Копіювання змінної у іншу
string = number;

// Виведення змінних на екран
alert(number);
alert(string);

//Оголошення об'єкта з 5 властивостями
let obj = {
    str:"",
    numb: 45,
    isBool: true,
    undefinedValue : undefined,
    nullValue : null
};

//Оголошення булевої змінної та присвоєння їй результату функції confirm()
let isAdult = confirm("Вам уже є 18 років?");

//Виведення змінної isAdult
console.log(isAdult);

//Оголошення та визначення змінних, виведення їх типу данних та значення
let birthday = 2004;
console.log("Тип змінної:" + typeof birthday);
console.log("Значення змінної:" + birthday);

isMarried = false;
console.log("Тип змінної:" + typeof isMarried);
console.log("Значення змінної:" + isMarried);

let Name = "Володимир";
console.log("Тип змінної:" + typeof Name);
console.log("Значення змінної:" + Name);

let surname = "Козлівський";
console.log("Тип змінної:" + typeof surname);
console.log("Значення змінної:" + surname);

let group = "КН-321";
console.log("Тип змінної:" + typeof group);
console.log("Значення змінної:" + group);

//Визначення змінних спеціфичних типів даних: undefined , null.Виведення їх на екран
let undefinedValue;
console.log("Тип данних змінної undefinedValue: " + typeof undefinedValue);

let nullValue = null;
console.log("Тип данних змінної nullValue: " + typeof nullValue);

//Запит логіну, емейлу та паролю у користувача, запис їх у відповідні змінні
let login = prompt("What's your login?","admin");
let email = prompt("What's your email?","admin@gmail.com");
let password = prompt("What's your password?","password");

//Вивід значень на екран
alert("Dear " + login + ", your email is "+ email + ", password is "+ password + ".");

//Визначення кількості секунд у годині,дні,місяці.Виведення значень на екран
let hourSeconds = 60 * 60;
let daySeconds = 24 * hourSeconds;
let monthSeconds = 28 * daySeconds;

alert("Секунд в годині: " + hourSeconds);
alert("Секунд у добі : " + daySeconds);
alert("Секунд у місяці: " + monthSeconds);


