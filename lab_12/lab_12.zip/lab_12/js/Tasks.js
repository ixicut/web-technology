//ЗАВДАННЯ 1
let x = 1;
let y = 2;

let res1 = String(x) + String(y);// Допишіть код (використовувати змінні x і y)
console.log(res1); // "12"
console.log(typeof res1); // "string"

let res2 = Boolean(x) + String(y); // Допишіть код (використовувати змінні x і y)
console.log(res2); // "true2"
console.log(typeof res2); // "string"

let res3 = Boolean(x); // Допишіть код (використовувати змінні x і y)
console.log(res3); // true
console.log(typeof res3); // "boolean"

let res4 = Number(Boolean(x)+String(y));// Допишіть код (використовувати змінні x і y)
console.log(res4); // NaN
console.log(typeof res4); // "number"

//ЗАВДАННЯ 2
let number = prompt("Введіть число",0);

console.log("Число є парним та додатним: " + (number % 2 === 0 && number > 0));
console.log("Число є кратним 7: " + (number % 7 === 0));

//ЗАВДАННЯ 3
confirm("Вам уже є вісімнадцять років?") ? alert("Ви досягли повнолітнього віку.") : alert("Ви ще надто молоді.");

//ЗАВДАННЯ 4
let a = Number(prompt("Введіть першу сторону трикутника:"));
let b = Number(prompt("Введіть другу сторону трикутника:"));
let c = Number(prompt("Введіть третю сторону трикутника:"));

if(isNaN(a) || isNaN(b) || isNaN(c)||
a <= 0 || b <= 0 || c <= 0) alert("Incorrect data");

let p = (a+b+c)/2;
let S = Math.sqrt( p * (p - a) * (p - b) * (p - c) ); 

console.log("Периметр трикутника = " + S.toFixed(3));

if(a** 2 + b**2 === c**2 || b**2 + c**2 === a**2 || a**2 + c**2 === b**2) console.log("Трикутник є прямокутним");
else console.log("Трикутник не є прямокутним");

//ЗАВДАННЯ 5

let hour = new Date().getHours;
console.log(hour);

if(hour >= 23 && hour <= 5) alert("Доброї ночі");
else if(hour > 5 && hour <= 11) alert("Доброго ранку");
(hour > 11 && hour <= 17) ? alert("Доброго дня") : alert("Доброго вечора");












