//1 ЗАВДАННЯ

let array = [];
array[0] = 12;
array[1] = "string";
array[2] = true;
array[3] = null;
alert("Array size: " + array.length);
array[4] = prompt("Enter your number: ", "");
alert("fifth element is : " + array[4]);
array.splice(0,1);
console.log("array contains : ");
array.forEach(el => console.log(el));

//2 ЗАВДАННЯ

let cities = ["Ternopil", "Lviv", "Warsaw"];
console.log(cities.join("*"));

//3 ЗАВДАННЯ

let numbers = [2,3,4,5];
let mult = 1;

for(let i = 0; i < numbers.length;i++) mult*=numbers[i];
console.log("multiplication(with for) is: " + mult);
mult = 1;

let i = 0;
while(i < numbers.length) {
    mult*=numbers[i];
    ++i;
}
console.log("multiplication(with while) is: " + mult);

//4 ЗАВДАННЯ

for(let i = 0;i <= 15; i++) 
(i%2 === 0) ? console.log(i + " is even") :console.log(i + " is odd");

//5 ЗАВДАННЯ

function randArray(n){
    let arr = [];
    for(let i = 0; i < n; i++) arr[i] = Math.round((Math.random() * 499 + 1));
    arr.forEach(el => console.log(el));
    return arr;
}

let someArray = randArray(5);

//6 ЗАВДАННЯ

function raiseToDegree(a,b){
    return a**b;
}

let a = Number(prompt("Enter the number that will be raised to the power",""));
let b = Number(prompt("Enter the degree",""));

if(Number.isInteger(a) && Number.isInteger(b)) alert("Result is : " + raiseToDegree(a,b));
else alert("some number is not integer");

//7 ЗАВДАННЯ

function findMin(){
    let min = arguments[0];
    for(let i = 1 ;i < arguments.length; i++) if(arguments[i] < min) min = arguments[i];
    console.log("The min value is : " + min);
    return min;
}

//8 ЗАВДАННЯ

function findUnique(arr){
let resArr = [];

for(let i = 0; i < arr.length;i++) 
    if(!resArr.includes(arr[i])) resArr.push(arr[i]);
    return arr.length === resArr.length;
}

switch(findUnique([34,5,6,7,6,345,-324])){
case true: console.log("Array is unique!");
    break;
case false: console.log("Array is not unique!");
    break;
}

//9 ЗАВДАННЯ

function lastElem(a,b){
if(b === undefined) b = 1;
return a.slice(a.length - b);
}

console.log("The last element/elements is/are: ");
let array2 = lastElem([2,4,6,4,3,5],23);
array2.forEach(el => console.log(el));

//10 ЗАВДАННЯ

function toUpper(a){
    let words = a.split(" ");
    
    for(let i = 0; i < words.length;i++)
        words[i] = words[i].charAt(0).toUpperCase() + words[i].substring(1);
    
    return words.join(" ");
}

console.log("first letters of next string must be in upper case: " + toUpper("first letters in upper case"));
