// ЗАВДАННЯ 1

function calcRectangleArea(width,height){
if(height === undefined) throw new Error("The height is undefined");
if(isNaN(width) || isNaN(height)) throw new Error("The values are not numbers");
return width*height;
}

try{
    console.log(calcRectangleArea(2,"df"));
} catch(e){
    console.log(e.message);
}

// ЗАВДАННЯ 2

 function checkAge(){
 let age = prompt("Enter your age: ","");
if(age === null || age.length === 0) throw Error("The field is empty! Please enter your age");
if(isNaN(age)) throw Error("Please, enter a number value");
if(Number(age) < 14) throw Error("Sorry, your age is lesser than 14 year");
 alert("You have gained access to the movie, please enjoy!");
}

 try{
    checkAge();
 } catch(e){
    alert("Назва помилки: " + e.name + "\n" + "Опис помилки: " + e.message);
 }


 // ЗАВДАННЯ 3

 function showUser(id){
     if(id < 0) throw RangeError("ID must not be negative: " + id);
     else return {"id": id};
 }
    
 function showUsers(ids){
     let res = [];
     for(let i = 0; i < ids.length; i++)
     {
        try{
            res.push(showUser(ids[i]));
        } catch(e){console.log(e.message);}
     }
     return res;
 }

 let test = showUsers([-34,5,7,132,-5]);

 // ЗАВДАННЯ 4

 class MonthException
{
    constructor(message)
    {
        this.name = "MonthException";
        this.message = message;
    }
}

function showMonthName(month){
    if(isNaN(month)) throw new MonthException("Incorrect month number");
    if(!Number.isInteger(month)) throw new MonthException("Incorrect month number");
    switch(month){
    case 1: return "January";
        break;
    case 2: return "February";
        break;
    case 3: return "March";
        break;
    case 4: return "April";
        break;
    case 5: return "May";
        break;
    case 6: return "June";
        break;
    case 7: return "July";
        break;
    case 8: return "August";
        break;
    case 9: return "September";
        break;
    case 10: return "October";
        break;
    case 11: return "November";
        break;
    case 12: return "December";
        break;
    default: throw new MonthException("Incorrect month number"); 
    }
}

try{
    console.log(showMonthName(23.4));
} catch(e){
    console.log(e.message);
}
