// ЗАВДАННЯ 1

function propsCount(currentObject){
    return Object.keys(currentObject).length;
}

let mentor = {
    course: "JS fundamental",
    duration: 3,
    direction: "web-development"
    };

console.log("count of properties is " + propsCount(mentor));

// ЗАВДАННЯ 2

function showProps(obj){
    console.log("Prop names are :");
    Object.keys(obj).forEach(p => console.log(p));

    console.log("Prop values are :");
    Object.values(obj).forEach(v => console.log(v));   
}

let testObj = {
    field1: "value1",
    field2: "value2",
    field3: "value3",
    field4: "value4",
    field5: "value5"
};

showProps(testObj);

// ЗАВДАННЯ 3

const CURRENT_YEAR = 2022;

class Person{
    constructor(name,surname){
        this.name = name;
        this.surname = surname;
    }

    showFullName() {
    console.log("The full name is " + this.name + " " + this.surname);
    }
}

let testPerson = new Person("John","Arabovich");
testPerson.showFullName();

class Student extends Person{
    constructor(name,surname,year){
        super(name,surname);
        this.year = year;
    }

    showFullName(midleName){
        console.log("The full name is " + this.name + " " + this.surname + " " + midleName);
    }

    showCourse(){
        return CURRENT_YEAR - this.year;
    }

}

const stud1 = new Student("Petro", "Petrenko", 2016);
console.log(stud1.showFullName("Petrovych"));
console.log("Current course: " + stud1.showCourse()); 

// ЗАВДАННЯ 4

class Worker{

    #experience = 1.2;

    constructor(fullName,dayRate,workingDays){
        this.fullName = fullName;
        this.dayRate = dayRate;
        this.workingDays = workingDays;
    }

    showSalary(){
        console.log(this.fullName + " salary is " + this.dayRate*this.workingDays);
    }

    showSalaryWithExperience(){
        console.log(this.fullName + " salary with experience is " + this.dayRate*this.workingDays*this.#experience);
    }
    
    set setExperience(exp){
        this.#experience = exp;
    }

    get getExperience(){
        return this.#experience;
    }

    get getSalaryWithExp(){
        return this.dayRate*this.workingDays*this.#experience;
    }

}

let worker1 = new Worker("John Johnson", 20, 23);
console.log(worker1.fullName);
worker1.showSalary();
console.log("New experience: " + worker1.getExperience);
worker1.showSalaryWithExperience();
worker1.setExperience = 1.5;
console.log("New experience: " + worker1.getExperience);
worker1.showSalaryWithExperience();

let worker2 = new Worker("Tom Tomson", 48, 22);
let worker3 = new Worker("Andy Ander", 29, 23);

worker3.setExperience = 1.1;

let workers = [];
workers.push(worker1);
workers.push(worker2);
workers.push(worker3);

workers.sort(function(a,b){
    return a.getSalaryWithExp - b.getSalaryWithExp;
});

console.log("Sorted salary: ");
workers.forEach(o=>console.log(o.fullName + ": " + o.getSalaryWithExp));

// ЗАВДАННЯ 5

class GeometricFigure {
    getArea() {
    return 0;
}
    toString() {
     return Object.getPrototypeOf(this).constructor.name;
    }
}

class Triangle extends GeometricFigure{
    constructor(a,b,c){
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }

    getArea(){
        let p = (this.a+this.b+this.c)/2;
        return Math.sqrt( p * (p - this.a) * (p - this.b) * (p - this.c) ); 
    }

}

class Square extends GeometricFigure{
    constructor(side){
        super();
        this.side = side;
    }

    getArea(){
        return this.side**2;
    }
}

class Circle extends GeometricFigure{
    constructor(r){
        super();
        this.r = r;
    }

    getArea(){
        return 2*Math.PI*this.r;
    }
}

function  handleFigures(figures){

    let sum = 0;
    for(let i = 0; i < figures.length; i++){
        if(figures[i] instanceof GeometricFigure) {
            console.log("Object name : " + figures[i].toString());
            console.log("Object area : " + figures[i].getArea());
            sum+= figures[i].getArea();
        } else console.log("Object name is "
         + Object.getPrototypeOf(figures[i].constructor.name + ", so , it's not a figure!")); 
    }

    console.log("The sum of all areas is " + sum);

}
    
const figures = [new Triangle(4, 5, 6), new Square(7), new Circle(5)];
handleFigures(figures);

