// ЗАВДАННЯ 1

document.getElementById("test").innerHTML = "Last";

document.querySelector("body div").innerHTML = "Last";

// ЗАВДАННЯ 2

document.getElementsByClassName("image")[0].src = "cat.jpg";

alert("src тегу image: " + document.getElementsByClassName("image")[0].src);

// ЗАВДАННЯ 3

let coll = document.querySelectorAll("div#text p");

for(let i = 0;i < coll.length;i++) console.log("Selector text " + i + ":" + coll[i].innerHTML);

// ЗАВДАННЯ 4

liColl = document.querySelectorAll("ul#list li");

alert(liColl[0].innerHTML + "\n" + liColl[4].innerHTML + "\n" + liColl[1].innerHTML 
+ "\n" + liColl[3].innerHTML + "\n" + liColl[2].innerHTML);

// ЗАВДАННЯ 5

document.querySelector("body h1").style.backgroundColor = "green";
myColl = document.querySelectorAll("div#myDiv p");
myColl[0].style.fontWeight = "bold";
myColl[1].style.color = "red";
myColl[2].style.textDecoration = "underline";
myColl[3].style.fontStyle = "italic";

myLiColl = document.querySelectorAll("ul#myList li").
forEach(e=>e.style.display = "inline");

document.querySelector("body span").style.display = "none";

// ЗАВДАННЯ 6

let message1 = prompt("Write your first message","");
let message2 = prompt("Write your second message","");

inp1 = document.getElementById("input1");
inp2 = document.getElementById("input2");

inp1.value = message1;
inp2.value = message2;

let temp = inp1.value;
inp1.value = inp2.value;
inp2.value = temp;

// 7 ЗАВДАННЯ

let main = document.createElement("main");
let div = document.createElement("div");
let p = document.createElement("p");

main.className = "mainClass check item";
div.id = "myDiv";
p.innerHTML = "First paragraph";

document.body.append(main);

main.append(div);
div.append(p);