// ЗАВДАННЯ 1 

let newWindow = window.open("","","width=300,height=300");

window.setTimeout(function(){
    newWindow.resizeTo(500,500);
},2000);

window.setTimeout(function(){
    newWindow.moveTo(200,200);
},4000);

window.setTimeout(function(){
    newWindow.close();
},6000);

// 2 ЗАВДАННЯ

function changeCSS(){
 let p = document.getElementById("text");
 p.style.color = "orange";
 p.style.fontSize = "20px";
 p.style.fontFamily = "Comic Sans MS";
}

document.getElementById("myBtn").addEventListener("click",changeCSS);

// 3 ЗАВДАННЯ


document.getElementById("myBtn2").addEventListener("click",function(){
    document.body.style.backgroundColor = "blue";
});

document.getElementById("myBtn3").addEventListener("dblclick",function(){
    document.body.style.backgroundColor = "pink";
});

document.getElementById("myBtn4").addEventListener("mousedown",function(){
    document.body.style.backgroundColor = "brown";
});

document.getElementById("myBtn4").addEventListener("mousedown",function(){
    document.body.style.backgroundColor = "brown";
});

document.getElementById("myBtn4").addEventListener("mouseup",function(){
    document.body.style.backgroundColor = "white";
});

document.getElementById("link").addEventListener("mouseover",function(){
    document.body.style.backgroundColor = "yellow";
});

document.getElementById("link").addEventListener("mouseout",function(){
    document.body.style.backgroundColor = "white";
});

// 4 ЗАВДАННЯ

document.getElementById("selectBtn").addEventListener("click",function(){
    let select = document.getElementById("select");
    let val = select.value;
    select.removeChild(select.querySelector('option[value=\"' + val +  '\"]')); 
});

// 5 ЗАВДАННЯ

let liveButton = document.getElementById("myBtn5");
let container = document.getElementById("container");

function createPWithText(text){
    let p = document.createElement("p");
    p.innerHTML = text;
    return p;
}

liveButton.addEventListener("click",function(){
    container.appendChild(createPWithText("I was pressed!"));
});

liveButton.addEventListener("mouseover",function(){
    container.appendChild(createPWithText("Mouse on me!"));
});

liveButton.addEventListener("mouseout",function(){
    container.appendChild(createPWithText("Mouse is not on me!"));
});

// 6 ЗАВДАННЯ

let sizeP = document.getElementById("size");

function showHeightAndWidth(){
    sizeP.innerHTML = "Height: " + this.innerHeight + "; Width: " + this.innerWidth;
}

showHeightAndWidth();
window.addEventListener("resize",showHeightAndWidth);

// 7 ЗАВДАННЯ

let gerCities = ["Berlin","Bonn","Bielefeld"];
let usaCities = ["New York","Los Angeles","Houston"];
let ukrCities = ["Lviv","Kyiv","Poltava"];


function createOptionsAndAppend(arr,select){
    
    for(let i = 0; i < Object.keys(arr).length; i++){
    let option = new Option(arr[i],i);
    select.appendChild(option);
    }
}

function dropOptions(){
    countrySelect = document.getElementById("cities");
    let len = document.getElementById("cities").length;

    for(let i = 0;i < len;i++){
    countrySelect.removeChild(countrySelect.querySelector('option[value=\"' + countrySelect.value +  '\"]')); 
    }
}

function checkCountryAndSetCities(){
    
    dropOptions();
    let countrySelect = document.getElementById("country");
    let citiesSelect = document.getElementById("cities");

    if(countrySelect.value === "ger") createOptionsAndAppend(gerCities,citiesSelect);
    else if(countrySelect.value === "usa") createOptionsAndAppend(usaCities,citiesSelect);
    else if(countrySelect.value == "ukr") createOptionsAndAppend(ukrCities,citiesSelect); 
    showCountryAndCity();
}

function showCountryAndCity(){
    let countrySelect = document.getElementById("country");
    let citiesSelect = document.getElementById("cities");
    let p1 = document.getElementById("countryAndCity");

    p1.innerHTML = countrySelect.options[countrySelect.selectedIndex].text + ","
    + citiesSelect.options[citiesSelect.selectedIndex].text
}

checkCountryAndSetCities();

document.getElementById("country").addEventListener("change",checkCountryAndSetCities);

document.getElementById("cities").addEventListener("change",showCountryAndCity);

