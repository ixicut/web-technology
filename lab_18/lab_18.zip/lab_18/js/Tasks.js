// 1 ЗАВДАННЯ

function testIfUpperCase(str){
    let upperCaseRegExp = /^[A-Z]/; 
    (upperCaseRegExp.test(str)) ?
    console.log("String's starts with uppercase character") : 
    console.log("String's not starts with uppercase character");
}

testIfUpperCase("hello!");

// 2 ЗАВДАННЯ

function replaceSubStrings(str){
    return str.split(" ").reverse().join(",");
}

console.log(replaceSubStrings("Hello World"));

// 3 ЗАВДАННЯ

function cardNumberIsValid(str){
    let cardRegExp = /^9{4}-9{4}-9{4}-9{4}$/;
    return cardRegExp.test(str);
}

console.log("Card 4563-3522-6786-3456 is valid? : " + cardNumberIsValid("4563-3522-6786-3456"));
console.log("Card 9999-9999-9999-9999 is valid? : " + cardNumberIsValid("9999-9999-9999-9999"));

// 4 ЗАВДАННЯ

function checkEmail(str){
    let emailRegExp = /^(\w+)-?(\w+)-?@(\w+)\.(\w+)$/;
    (emailRegExp.test(str)) ? 
    console.log("Email " + str + " is correct!") :
    console.log("Email " + str + " is not correct!");
}

checkEmail("my_mail@gmail.com");
checkEmail("#my_mail@gmail.com");
checkEmail("my_ma--il@gmail.com");

// 5 ЗАВДАННЯ

function checkLogin(str){
    let loginRegExp = /^[A-Za-z][A-Za-z0-9.]{1,9}$/;
    var numbersRegExp = /\d+\.?(\d+)?/g
    let numbers = str.match(numbersRegExp);
    console.log("All numbers in the next string: ");
    numbers.forEach(e=>console.log(e));
    return loginRegExp.test(str);
}

console.log("Login ee1.1ret3 is... " + checkLogin("ee1.1ret3"));
console.log("Login ee1*1ret3 is... " + checkLogin("ee1*1ret3"));