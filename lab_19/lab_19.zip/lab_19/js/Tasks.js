// 1 ЗАВДАННЯ

$("a").filter(function(){
    return /^https:\/\//.test(this.getAttribute("href"));
}).attr("target","_blank");

// 2 ЗАВДАННЯ

$("h2.head").css("background-color", "green");
$("h2.head").find(".inner").css("font-size","35px");

// 3 ЗАВДАННЯ

let h3s = document.querySelectorAll("h3");
let divs = document.querySelectorAll("h3+div");

$("h3").remove();

for(let i = 0;i < divs.length;i++){
    divs[i].after(h3s[i]);
}

// 4 ЗАВДАННЯ

$("input[type = 'checkbox']").on("change", function () {
    if ($("input[type = 'checkbox']").filter(":checked").length === 3)
    $("input[type = 'checkbox']").attr("disabled", true);
});