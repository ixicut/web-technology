// 1 ЗАВДАННЯ

console.log("1 ЗАВДАННЯ");
let arr = ["Tom", "Sam", "Ray", "Bob"];
let [x,y,,...z] = arr;

console.log(x); // "Tom"
console.log(y); // "Sam"
console.log(z); // [Bob]

// 2 ЗАВДАННЯ

console.log("2 ЗАВДАННЯ");
let data = {
    names: ["Sam", "Tom", "Ray", "Bob"],
    ages: [20, 24, 22, 26],
   };
   let {names: [,name2,,name4] , ages:[,age2,,age4]} = data;
   console.log(name2); // "Tom"
   console.log(age2); // 24
   console.log(name4); // "Bob"
   console.log(age4); // 26

// 3 ЗАВДАННЯ
console.log("3 ЗАВДАННЯ");

function mul(...rest) {
    rest = rest.filter((el)=>(typeof el === "number"));
    return (rest.length !== 0) ? rest.reduce((el1,el2)=>el1*el2,1) : 0;
}

console.log("There are some numbers in array and mul is " + mul("ddd", 45, "dd", 67, true)); //6
console.log("There are no numbers in array, so mul is " + mul("ddd", false, "dd","test", true));

// 4 ЗАВДАННЯ
console.log("4 ЗАВДАННЯ");
function mapBuilder(keys, values){
    let array = [];
    for(let i = 0;i < keys.length;i++) array.push([keys[i],values[i]]);
    return new Map(array);
}

let keys = [1, 2, 3, 4];
let values = ["div", "span", "b", "i"];
let map = mapBuilder(keys, values);
console.log(map);
console.log(map.size); // 4
console.log(map.get(2)); // "span"